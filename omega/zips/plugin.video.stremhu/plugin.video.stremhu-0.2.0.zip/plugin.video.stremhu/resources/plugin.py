# Module: default
# Author: s4pp1
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from lib.plugin import run

if __name__ == "__main__":
    run()
