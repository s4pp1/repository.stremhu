from __future__ import annotations

from typing import Any, List

import xbmcgui
import xbmcplugin
import xbmcvfs

from ...common import notification
from ...context import ADDON, PLUGIN
from ...integrations.source.models import KodiImdbStreamDto, KodiImdbStreamsDto


def resolve_resolution_icon(
    stream: KodiImdbStreamDto,
) -> str:
    resolution = stream.resolution.value.value
    icon_path = "{}/resources/media/resolution/{}.png".format(
        ADDON.getAddonInfo("path"),
        resolution,
    )

    if xbmcvfs.exists(icon_path):
        return icon_path

    return ADDON.getAddonInfo("icon")


def join_meta_labels(items: list[Any]) -> str:
    labels = [str(item.label).strip() for item in items if getattr(item, "label", "")]
    return ", ".join([label for label in labels if label])


def join_non_empty_parts(parts: list[str | None]) -> str:
    return ", ".join([part for part in parts if part])


def format_seeders(seeders: float) -> str:
    return f"{int(seeders)} seed"


def build_stream_label(stream: KodiImdbStreamDto) -> str:
    tracker_label = f"{stream.tracker.label}"
    video_qualities = join_meta_labels(stream.videoQualities)
    languages = join_meta_labels(stream.languages)

    return join_non_empty_parts([tracker_label, video_qualities, languages])


def build_stream_label2(stream: KodiImdbStreamDto) -> str:
    audio_quality = stream.audioQuality.label if stream.audioQuality else None
    audio_spatial = stream.audioSpatial.label if stream.audioSpatial else None

    return join_non_empty_parts(
        [
            audio_quality,
            audio_spatial,
            format_seeders(stream.seeders),
            stream.size,
        ]
    )


def choose_stream_and_play(
    title: str,
    stream_information: KodiImdbStreamsDto,
):

    if stream_information.errors:
        notification(
            message=" ,".join(stream_information.errors),
            error=True,
        )

    if not stream_information.streams:
        xbmcgui.Dialog().ok(
            heading="Nincs elérhető torrent",
            message="Ehhez a tartalomhoz nincs elérhető torrent, vagy nincs találat a StremHU Source beállításai alapján.",
        )
        xbmcplugin.setResolvedUrl(
            handle=PLUGIN.handle,
            succeeded=False,
            listitem=xbmcgui.ListItem(),
        )
        return

    items: List[str | xbmcgui.ListItem] = []

    for stream in stream_information.streams:
        icon = resolve_resolution_icon(stream)

        li = xbmcgui.ListItem(
            label=build_stream_label(stream),
            label2=build_stream_label2(stream),
        )
        li.setArt({"icon": icon, "thumb": icon})

        items.append(li)

    heading = "Stream kiválasztása"
    selected_index = xbmcgui.Dialog().select(
        heading=heading,
        list=items,
        useDetails=True,
    )

    if selected_index < 0:
        xbmcplugin.setResolvedUrl(
            handle=PLUGIN.handle,
            succeeded=False,
            listitem=xbmcgui.ListItem(),
        )
        return

    selected_stream = stream_information.streams[selected_index]
    play_item = xbmcgui.ListItem(path=selected_stream.url)
    play_item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(
        handle=PLUGIN.handle,
        succeeded=True,
        listitem=play_item,
    )
