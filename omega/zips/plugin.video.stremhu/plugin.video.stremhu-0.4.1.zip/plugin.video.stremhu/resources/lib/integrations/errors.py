class ApiError(Exception):
    pass
